import styles from './EarningsTrend.module.css'

export default function EarningsTrend({ history }) {
  if (!history?.length) return <span className="neutral">—</span>

  // Show up to 3 quarters, most recent first
  const quarters = history.slice(0, 3)

  return (
    <div className={styles.trend}>
      {quarters.map((q, i) => {
        const pct = q.surprise_pct
        const label = pct != null
          ? `${q.beat ? '+' : ''}${pct.toFixed(1)}%`
          : (q.beat ? 'Beat' : 'Miss')
        const dateLabel = q.date ? q.date.slice(0, 7) : '' // YYYY-MM

        return (
          <div
            key={i}
            className={`${styles.pill} ${q.beat ? styles.beat : styles.miss}`}
            title={`EPS Est: ${q.estimated_eps} / Act: ${q.actual_eps}`}
          >
            <span className={styles.date}>{dateLabel}</span>
            <span className={styles.pct}>{label}</span>
          </div>
        )
      })}
    </div>
  )
}
