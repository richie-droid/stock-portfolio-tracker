import yfinance as yf
from typing import Optional
import pandas as pd


def get_ticker_data(ticker: str) -> dict:
    """
    Fetch current price, next earnings date, and last 3 earnings results for a ticker.
    Returns dict with current_price, next_earnings_date, earnings_history (list of 3).
    """
    result = {
        "current_price": None,
        "next_earnings_date": None,
        "earnings_history": [],
    }
    try:
        t = yf.Ticker(ticker)

        # Current price
        try:
            info = t.fast_info
            result["current_price"] = round(float(info.last_price), 4)
        except Exception:
            pass

        # Next earnings date
        try:
            cal = t.calendar
            if isinstance(cal, dict):
                ed = cal.get("Earnings Date")
                if ed:
                    result["next_earnings_date"] = str(ed[0] if isinstance(ed, list) else ed)[:10]
            elif hasattr(cal, "loc"):
                ed = cal.loc["Earnings Date"]
                result["next_earnings_date"] = str(ed.iloc[0] if hasattr(ed, "iloc") else ed)[:10]
        except Exception:
            pass

        # Last 3 earnings — date, surprise %
        try:
            eh = t.earnings_history
            if eh is not None and not eh.empty:
                eh = eh.sort_values("quarter", ascending=False).head(3)
                for _, row in eh.iterrows():
                    estimated = row.get("epsEstimate")
                    actual = row.get("epsActual")
                    surprise = row.get("epsDifference")
                    if pd.isna(estimated) or pd.isna(actual):
                        continue
                    beat = float(actual) >= float(estimated)
                    surprise_pct = round(float(surprise) * 100, 2) if not pd.isna(surprise) else None
                    result["earnings_history"].append({
                        "date": str(row.get("quarter", ""))[:10],
                        "estimated_eps": round(float(estimated), 3),
                        "actual_eps": round(float(actual), 3),
                        "surprise_pct": surprise_pct,
                        "beat": beat,
                    })
        except Exception:
            pass

    except Exception:
        pass

    return result


def get_ticker_info_batch(tickers: list[str]) -> dict:
    results = {}
    for ticker in tickers:
        results[ticker] = get_ticker_data(ticker)
    return results
